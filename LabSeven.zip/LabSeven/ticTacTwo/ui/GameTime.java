package ticTacTwo.ui;

import javax.swing.JPanel;
import java.awt.GridLayout;

public class GameTime
{
    protected JPanel panel;
    protected TileButton[][] buttons;
    private DisplayPanel displayPanel;

    public JPanel getPanel()
    {
        return this.panel;
    }

    public GameTime(DisplayPanel displayPanel)
    {
        this.displayPanel = displayPanel;
        panel = new JPanel();
        panel.setLayout(new GridLayout(3, 3));
        buttons = new TileButton[3][3];
        for (int row = 0; row < 3; row++) 
        {
            for (int col = 0; col < 3; col++) 
            {
                buttons[row][col] = new TileButton(row, col, displayPanel);
                panel.add(buttons[row][col].getButton());
            }
        }
    }

    public void makeMove(char[][] gameBoard) 
    {
        for (int row = 0; row < 3; row++) 
        {
            for (int col = 0; col < 3; col++) 
            {
                buttons[row][col].getButton().setText(String.valueOf(gameBoard[row][col]));
                if (gameBoard[row][col] != '\0') 
                {
                    buttons[row][col].getButton().setEnabled(false);
                }
            }
        }
    }
    public void newGame()
    {
         for (int row = 0; row < 3; row++) 
         {
            for (int col = 0; col < 3; col++) 
            {
                buttons[row][col].getButton().setText("");
                buttons[row][col].getButton().setEnabled(true);
            }
        }
    }
}