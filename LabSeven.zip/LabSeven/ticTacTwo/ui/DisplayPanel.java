package ticTacTwo.ui;

import javax.swing.JPanel;
import ticTacTwo.logic.GameLogic;

public class DisplayPanel
{
    JPanel panel;
    GameStart gameStart;
    GameTime gameTime;
    GameLogic logic;

    public JPanel getPanel()
    {
        return panel;
    }
    public GameStart getGameStart()
    {
        return gameStart;
    }
    public GameTime getGameTime() 
    {
        return gameTime;
    }
    public GameLogic getLogic()
    {
        return this.logic;
    }

    public DisplayPanel(GameLogic logic)
    {
        this.logic = logic;
        panel = new JPanel();
        gameStart = new GameStart(this);
        gameTime = new GameTime(this);
        panel.add(gameStart.getPanel());
    }

    //Revalidate and Repaint is apparently needed for it to display properly. Just another fun quirk of Swing.
    public void showStartPanel()
    {
        panel.remove(gameTime.getPanel());
        panel.add(gameStart.getPanel());
        panel.revalidate();
        panel.repaint();
    }
    public void showGamePanel()
    {
        gameTime.newGame();
        logic.newGame();
        panel.remove(gameStart.getPanel());
        panel.add(gameTime.getPanel());
        panel.revalidate();
        panel.repaint();
    }
    public void displayWinText(String text)
    {
        gameStart.displayText(text);
    }
}