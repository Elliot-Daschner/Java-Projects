package ticTacTwo.ui;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class GameStart
{
    private JPanel panel;
    private JLabel label;
    private StartButton startButton;
    private DisplayPanel displayPanel;

    public JPanel getPanel()
    {
        return this.panel;
    }

    public GameStart(DisplayPanel displayPanel)
    {
        this.displayPanel = displayPanel;
        panel = new JPanel();
        label = new JLabel("");
        startButton = new StartButton(displayPanel);
        panel.add(label);
        panel.add(startButton.getButton());
    }

    public void displayText(String text)
    {
        label.setText(text);
    }
}