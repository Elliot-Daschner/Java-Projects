package ticTacTwo.ui;

import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartButton
{
    private JButton button;
    private DisplayPanel displayPanel;

    public JButton getButton()
    {
        return this.button;
    }

    public StartButton(DisplayPanel displayPanel)
    {
        this.button = new JButton("New Game");
        button.addActionListener
        (
            new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) 
                {
                    displayPanel.showGamePanel();
                }
            }
        );
    }
}