package ticTacTwo.ui;

import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TileButton
{
    private JButton button;
    private int row;
    private int col;
    private DisplayPanel displayPanel;

    public JButton getButton()
    {
        return this.button;
    }

    public TileButton(int row, int col, DisplayPanel displayPanel)
    {
        this.row = row;
        this.col = col;
        this.displayPanel = displayPanel;
        this.button = new JButton("");
        button.addActionListener
        (
            new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) 
                {
                    displayPanel.getLogic().makeMove(row, col);
                }
            }
        );
    }
}