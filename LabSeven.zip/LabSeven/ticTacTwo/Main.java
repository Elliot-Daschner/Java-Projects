package ticTacTwo;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import ticTacTwo.logic.GameLogic;
import ticTacTwo.ui.*;

public class Main
{
    public static void main(String[] args)
    {
        //It seems that Swing needs a Runnable to do invokeLater with in order to run the display
        SwingUtilities.invokeLater
        (
            new Runnable() 
            {
                public void run() 
                {
                    JFrame frame = new JFrame("Tic-Tac-Toe");
                    frame.setSize(720, 720);
                    GameLogic logic = new GameLogic();
                    DisplayPanel display = new DisplayPanel(logic);
                    logic.setDisplayPanel(display);
                    frame.add(display.getPanel());
                    frame.setVisible(true);
                }
            }
        );
    }
}