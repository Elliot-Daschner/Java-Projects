package employeeManagementSystem;

public interface EmployeeInterface 
{
    double calculateSalary();
    void displayDetails();
}